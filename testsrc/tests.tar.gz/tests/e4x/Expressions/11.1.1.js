/* -*- Mode: java; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 4 -*-
 *
 * ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Rhino code, released
 * May 6, 1999.
 *
 * The Initial Developer of the Original Code is
 * Netscape Communications Corporation.
 * Portions created by the Initial Developer are Copyright (C) 1997-2000
 * the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 *   Igor Bukanov
 *   Ethan Hugg
 *   Milen Nankov
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

gTestfile = '11.1.1.js';

START("11.1.1 - Attribute Identifiers");

x =
<alpha>
    <bravo attr1="value1" ns:attr1="value3" xmlns:ns="http://someuri">
        <charlie attr1="value2" ns:attr1="value4"/>
    </bravo>
</alpha>
   
TEST_XML(1, "value1", x.bravo.@attr1);
TEST_XML(2, "value2", x.bravo.charlie.@attr1);

correct = new XMLList();
correct += new XML("value1");
correct += new XML("value2");
TEST(3, correct, x..@attr1);

n = new Namespace("http://someuri");
TEST_XML(4, "value3", x.bravo.@n::attr1);
TEST_XML(5, "value4", x.bravo.charlie.@n::attr1);

correct = new XMLList();
correct += new XML("value3");
correct += new XML("value4");
TEST(6, correct, x..@n::attr1);

q = new QName(n, "attr1");
TEST(7, correct, x..@[q]);

correct = new XMLList();
correct += new XML("value1");
correct += new XML("value3");
correct += new XML("value2");
correct += new XML("value4");
TEST(8, correct, x..@*::attr1);

TEST_XML(9, "value1", x.bravo.@["attr1"]);
TEST_XML(10, "value3", x.bravo.@n::["attr1"]);
TEST_XML(11, "value3", x.bravo.@[q]);

END();
